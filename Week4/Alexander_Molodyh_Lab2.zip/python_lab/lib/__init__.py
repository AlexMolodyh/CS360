from basic_shape import Cylinder
from modifiers import Vector
from modifiers import Pigment
from modifiers import Finish