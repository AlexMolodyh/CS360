
#include <stdio.h>

// fixed length, static storage
int ages[6] = {3,5,19,22,78,31};

int main()
{
    int i;
    for( i = 0; i < 6; ++i )
    {
        printf("%d,",ages[i]);
    }
    printf("\n");
    printf("First element located at address: %p\n",ages);
    printf("Local variable i located at address: %p\n",&i);
    return 0;
}


/*
#include <stdio.h>

int main()
{
    // fixed length, stack storage allocation ("automatic" variable)
    int ages[6] = {3,5,19,22,78,31};
    
    int i;
    for( i = 0; i < 6; ++i )
    {
        printf("%d,",ages[i]);
    }
    printf("\n");
    printf("First element located at address: %p\n",ages);
    printf("Local variable i located at address: %p\n",&i);
    return 0;
}
*/

/*
#include <stdio.h>
#include <stdlib.h>

int main()
{
    // fixed length, heap storage allocation
    int length = 6;
	int * ages = (int *)malloc(length*sizeof(int));
    
    int i;
    for( i = 0; i < 6; ++i )
    {
        printf("%d,",ages[i]);
    }
    printf("\n");
    printf("First element located at address: %p\n",ages);
    printf("Local variable i located at address: %p\n",&i);
    free(ages);
    return 0;
}

*/
